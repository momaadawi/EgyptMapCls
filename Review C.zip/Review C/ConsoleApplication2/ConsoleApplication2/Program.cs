﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static bool myfun(int a)
        {
            if (a > 60)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Func<int, bool> d = myfun;
            Func<int, int> dd = (a) => { return a; };

             int[] arr = { 2, 4, 5, 6, 77, 8, 99, 100, 120,66,78 };
            var data = arr.Where(d).OrderBy(dd);

            foreach (var item in data)
            {
                Console.WriteLine(item);
            }



        }
    }
}
