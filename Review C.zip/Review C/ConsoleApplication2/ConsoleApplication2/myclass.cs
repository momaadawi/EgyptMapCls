﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
   static class myclass
    {
        public static void dd( this int a)
        {

        }
    }
}
