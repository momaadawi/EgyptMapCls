﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class myclass<t1>
    {
        public t1 x { get; set; }

        public void mydisplay(t1 a)
        {
           
        }
    }
}
