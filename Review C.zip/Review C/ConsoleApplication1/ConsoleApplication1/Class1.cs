﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    static class dsfdsf
    {
        public static void show(this int a)
        {
            Console.WriteLine(a);
        }
        public static void Add(this int a,int b)
        {
            Console.WriteLine(a+b);
        }

    }
}
