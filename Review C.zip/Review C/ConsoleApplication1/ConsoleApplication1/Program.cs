﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {

        static void display(int [] arr)
        {

        }
        static void display2(List<int> mylist)
        {

        }
        static void display3(IEnumerable<int> mylist)
        {

        }

        static void myfun<dt>(dt x)
        {
            Console.WriteLine(x);
        }

        static void ddd<t1,t2>(t1 x,t2 y)
        {

        }

       // delegate void  (string a);
        //static void mydisplay(string x)
        //{
        //    Console.WriteLine("Welcome");
        //}
        static void Main(string[] args)
        {
            #region Ienumerable
            //int[] x = { 3, 4, 44 };
            //List<int> y = new List<int>() { 66, 77, 88 };

            //display(x);
            //display2(y);
            //display3(x);
            //display3(y);


            //int[] arr = new int[5];
            //arr[0] = 11;
            //arr[1] = 22;
            //arr[2] = 33;
            //arr[3] = 44;
            //arr[4] = 55;

            //var enm = arr.GetEnumerator();
            //while(enm.MoveNext())
            //{
            //    Console.WriteLine(enm.Current);
            //}

            #endregion


            #region generic

            //myfun<string>("aaaa");
            //myfun<int>(11);
            //myfun<double>(33.4);
            //myfun(3.4);



            //myclass<int> m = new myclass<int>();


            //List<int> mylist = new List<int>();
            //mylist.Add(11);
            //mylist.Add(44);

            //foreach (var item in mylist)
            //{
            //    Console.WriteLine(item);
            //}


            //List<string> mylist2 = new List<string>();
            //mylist2.Add("aaaa");


            //List<Country> mylist3 = new List<Country>();

            //Country c1 = new Country();
            //c1.Id = 1;
            //c1.CountryName = "Egypt";

            //mylist3.Add(c1);

            //Country c2 = new Country();
            //c2.Id = 2;
            //c2.CountryName = "Saudia";

            //mylist3.Add(c2);

            //foreach (var item in mylist3)
            //{
            //    Console.WriteLine(item.Id +  "   "+item.CountryName);
            //}

            #endregion

            #region extension
            //int x = 33;
            //x.show();
            //x.Add(11);

            //int y = 22;
            //y.show();
            #endregion

            //mydel d = (a) => { Console.WriteLine("welcome " + a); };

            //d("Ahmed");


            //Action d = () => { Console.WriteLine("aaaaaaaaaa"); };

            //d();


            //Action<int> dd = (a) => { Console.WriteLine(a); };

            //dd(44);


            Func<int> d = () => { return 11;  };


            Func<int, bool> dd = (x) => { return true; };

            
        }
    }
}
