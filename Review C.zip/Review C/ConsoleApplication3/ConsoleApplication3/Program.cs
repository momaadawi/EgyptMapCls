﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] arr = { 3, 5, 66, 7, 11, 2, 66, 77, 777 };
            //var data = arr.Skip(2).Take(3);
            //foreach (var item in data)
            //{
            //    Console.WriteLine(item);
            //}

            Func<int, bool> d = a => a>100;
            var data = arr.Where(d).SingleOrDefault();




            if (data == 0)
            {
                Console.WriteLine("no data");
            }
            else
            {
                Console.WriteLine(data);
            }



        }
    }
}
